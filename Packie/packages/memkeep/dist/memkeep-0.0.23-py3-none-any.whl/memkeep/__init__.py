# memkeep package file

import memkeep.mem as mem